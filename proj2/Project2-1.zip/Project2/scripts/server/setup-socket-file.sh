#!/bin/bash

# Creates Socket file if you choose to use this
touch ~/Desktop/cpre-308-socket
chmod 777 ~/Desktop/cpre-308-socket
