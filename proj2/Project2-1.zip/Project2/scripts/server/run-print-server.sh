#!/bin/bash

./main -d
