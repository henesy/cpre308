#!/bin/bash

./cli-rinter -l samplec.ps
