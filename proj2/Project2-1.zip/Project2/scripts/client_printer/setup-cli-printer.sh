#!/bin/bash
make clean
make
export LD_LIBRARY_PATH="../libprintserver/"

