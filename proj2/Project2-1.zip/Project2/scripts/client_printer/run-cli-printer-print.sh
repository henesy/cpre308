#!/bin/bash

./cli-printer -d color -s description -o first_test.pdf samplec.ps
