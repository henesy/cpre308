#!/bin/bash

rm ./drivers/*
make clean
make

