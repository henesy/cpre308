#!/bin/bash

./virt-printer -n printer0
./virt-printer -n printer3
